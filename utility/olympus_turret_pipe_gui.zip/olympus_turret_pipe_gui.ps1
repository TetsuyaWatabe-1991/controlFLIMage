# FLIMage Olympus turret pipe tester (PowerShell + WinForms, synchronous UI thread).
# Pipe logic matches test_flimage_pipe_connect.ps1 (no background threads).

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public static class RemoteControlCloser
{
    private delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll")]
    private static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

    private const uint WM_CLOSE = 0x0010;
    private static IntPtr _target = IntPtr.Zero;

    private static bool Callback(IntPtr hWnd, IntPtr lParam)
    {
        var sb = new StringBuilder(512);
        GetWindowText(hWnd, sb, sb.Capacity);
        if (sb.ToString().Contains("Remote control & script"))
            _target = hWnd;
        return true;
    }

    public static bool CloseRemoteControlWindow()
    {
        _target = IntPtr.Zero;
        EnumWindows(Callback, IntPtr.Zero);
        if (_target == IntPtr.Zero)
            return false;
        PostMessage(_target, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
        return true;
    }
}
"@

$TurretMin = 1
$TurretMax = 6
$HandshakeCode = "FLIMage"
$ReadPipeName = "FLIMageR"
$WritePipeName = "FLIMageW"
$ComInitDir = Join-Path $env:USERPROFILE "Documents\FLIMage\Init_Files\COM"
$ComInitFile = Join-Path $ComInitDir "COM_method.txt"
$ConnectTimeoutMs = 500
$ConnectRetries = 3

$script:PipeR = $null
$script:PipeW = $null
$script:PipeConnected = $false
$script:PipeLock = New-Object object
$script:Busy = $false

function Get-Timestamp {
    return (Get-Date).ToString("HH:mm:ss.fff")
}

function Read-PipeString([System.IO.Stream]$Stream) {
    $b1 = $Stream.ReadByte()
    $b2 = $Stream.ReadByte()
    if ($b1 -lt 0 -or $b2 -lt 0) { return $null }
    $len = ($b1 * 256) + $b2
    if ($len -le 0) { return "" }
    $buffer = New-Object byte[] $len
    $offset = 0
    while ($offset -lt $len) {
        $read = $Stream.Read($buffer, $offset, $len - $offset)
        if ($read -le 0) { break }
        $offset += $read
    }
    return [System.Text.Encoding]::UTF8.GetString($buffer, 0, $offset)
}

function Write-PipeString([System.IO.Stream]$Stream, [string]$Text) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $len = $bytes.Length
    if ($len -gt 65535) { $len = 65535 }
    $Stream.WriteByte([byte][math]::Floor($len / 256))
    $Stream.WriteByte([byte]($len -band 255))
    if ($len -gt 0) { $Stream.Write($bytes, 0, $len) }
    $Stream.Flush()
}

function Invoke-PipeHandshake {
    param(
        [System.IO.Pipes.NamedPipeClientStream]$Stream,
        [string]$PipeLabel
    )
    $first = Read-PipeString $Stream
    if ($first -ne $HandshakeCode) {
        return @{ Ok = $false; Detail = "$PipeLabel handshake step 1 failed (got '$first')" }
    }
    Write-PipeString $Stream $HandshakeCode
    $second = Read-PipeString $Stream
    if ($second -ne "Connected") {
        return @{ Ok = $false; Detail = "$PipeLabel handshake step 2 failed (got '$second')" }
    }
    return @{ Ok = $true; Detail = "" }
}

function Start-FlimagePipeServer {
    if (-not (Test-Path $ComInitDir)) {
        New-Item -ItemType Directory -Path $ComInitDir -Force | Out-Null
    }
    Set-Content -Path $ComInitFile -Value "PIPE" -Encoding ascii -NoNewline
}

function Close-FlimagePipes {
    foreach ($pipe in @($script:PipeW, $script:PipeR)) {
        if ($null -eq $pipe) { continue }
        try {
            if ($pipe.IsConnected) { $pipe.Close() }
            $pipe.Dispose()
        }
        catch { }
    }
    $script:PipeW = $null
    $script:PipeR = $null
    $script:PipeConnected = $false
}

function Reset-FlimageRemoteControl {
    param([scriptblock]$Log = $null)
    if ($null -ne $Log) { & $Log "Closing Remote control & script, then restarting PIPE server..." }
    $closed = [RemoteControlCloser]::CloseRemoteControlWindow()
    if ($null -ne $Log) {
        if ($closed) { & $Log "Remote control window close message sent." }
        else { & $Log "Remote control window not found." }
    }
    Start-Sleep -Milliseconds 150
    Start-FlimagePipeServer
    Start-Sleep -Milliseconds 250
}

function Connect-FlimagePipesOnce {
    param([scriptblock]$Log = $null)

    Close-FlimagePipes
    Start-FlimagePipeServer
    Start-Sleep -Milliseconds 150

    $pipeR = New-Object System.IO.Pipes.NamedPipeClientStream ".", $ReadPipeName, ([System.IO.Pipes.PipeDirection]::InOut)
    $pipeW = New-Object System.IO.Pipes.NamedPipeClientStream ".", $WritePipeName, ([System.IO.Pipes.PipeDirection]::InOut)

    try {
        $pipeR.Connect($ConnectTimeoutMs)
        $pipeW.Connect($ConnectTimeoutMs)
    }
    catch {
        if ($null -ne $Log) { & $Log "!! Pipe connect failed: $($_.Exception.Message)" }
        $pipeR.Dispose()
        $pipeW.Dispose()
        return $false
    }

    $hsR = Invoke-PipeHandshake -Stream $pipeR -PipeLabel $ReadPipeName
    if (-not $hsR.Ok) {
        if ($null -ne $Log) { & $Log $hsR.Detail }
        $pipeR.Dispose(); $pipeW.Dispose()
        return $false
    }

    $hsW = Invoke-PipeHandshake -Stream $pipeW -PipeLabel $WritePipeName
    if (-not $hsW.Ok) {
        if ($null -ne $Log) { & $Log $hsW.Detail }
        $pipeR.Dispose(); $pipeW.Dispose()
        return $false
    }

    $script:PipeR = $pipeR
    $script:PipeW = $pipeW
    $script:PipeConnected = $true
    return $true
}

function Connect-FlimagePipes {
    param([scriptblock]$Log = $null)

    if (Connect-FlimagePipesOnce -Log $Log) { return $true }

    for ($attempt = 2; $attempt -le $ConnectRetries; $attempt++) {
        if ($null -ne $Log) { & $Log "Connect attempt $attempt/$ConnectRetries" }
        Reset-FlimageRemoteControl -Log $Log
        if (Connect-FlimagePipesOnce -Log $Log) { return $true }
    }
    return $false
}

function Send-FlimagePipeCommand {
    param([string]$Command)
    if (-not $script:PipeConnected -or $null -eq $script:PipeW) {
        throw "Not connected to FLIMage pipe"
    }
    [System.Threading.Monitor]::Enter($script:PipeLock)
    try {
        Write-PipeString $script:PipeW $Command
        $reply = Read-PipeString $script:PipeW
        if ($null -eq $reply) {
            $script:PipeConnected = $false
            throw "Connection problem"
        }
        return $reply
    }
    finally {
        [System.Threading.Monitor]::Exit($script:PipeLock)
    }
}

function Get-TurretValue {
    param([string]$Reply, [string]$Token)
    if ([string]::IsNullOrWhiteSpace($Reply)) { return $null }
    $pattern = "{0}\s*,\s*(-?\d+)" -f [regex]::Escape($Token)
    $match = [regex]::Match($Reply, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $match.Success) { return $null }
    return [int]$match.Groups[1].Value
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "FLIMage Olympus Turret Pipe Tester (PowerShell)"
$form.Size = New-Object System.Drawing.Size 780, 650
$form.MinimumSize = New-Object System.Drawing.Size 680, 560
$form.StartPosition = "CenterScreen"

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.AutoSize = $true
$statusLabel.Location = New-Object System.Drawing.Point 12, 16
$statusLabel.Text = "Status: Disconnected"
$form.Controls.Add($statusLabel)

$btnConnect = New-Object System.Windows.Forms.Button
$btnConnect.Text = "Connect"
$btnConnect.Location = New-Object System.Drawing.Point 220, 10
$btnConnect.Width = 90
$form.Controls.Add($btnConnect)

$btnDisconnect = New-Object System.Windows.Forms.Button
$btnDisconnect.Text = "Disconnect"
$btnDisconnect.Location = New-Object System.Drawing.Point 320, 10
$btnDisconnect.Width = 90
$form.Controls.Add($btnDisconnect)

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = "Refresh turrets"
$btnRefresh.Location = New-Object System.Drawing.Point 420, 10
$btnRefresh.Width = 120
$form.Controls.Add($btnRefresh)

$logGroup = New-Object System.Windows.Forms.GroupBox
$logGroup.Text = "Sent / received log"
$logGroup.Location = New-Object System.Drawing.Point 12, 304
$logGroup.Size = New-Object System.Drawing.Size 740, 290
$form.Controls.Add($logGroup)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ScrollBars = "Vertical"
$logBox.ReadOnly = $true
$logBox.WordWrap = $false
$logBox.Font = New-Object System.Drawing.Font "Consolas", 9
$logBox.Location = New-Object System.Drawing.Point 12, 24
$logBox.Size = New-Object System.Drawing.Size 710, 220
$logGroup.Controls.Add($logBox)

$btnClearLog = New-Object System.Windows.Forms.Button
$btnClearLog.Text = "Clear log"
$btnClearLog.Location = New-Object System.Drawing.Point 632, 252
$btnClearLog.Width = 90
$logGroup.Controls.Add($btnClearLog)

function Add-Log {
    param([string]$Line)
    $logBox.AppendText("[$(Get-Timestamp)] $Line`r`n")
    $logBox.SelectionStart = $logBox.Text.Length
    $logBox.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Set-Status {
    param([bool]$Connected, [string]$Detail = "")
    if ($Connected) { $text = "Status: Connected" }
    else { $text = "Status: Disconnected" }
    if ($Detail) { $text += " - $Detail" }
    $statusLabel.Text = $text
}

function Set-Busy {
    param([bool]$IsBusy)
    $script:Busy = $IsBusy
    $btnConnect.Enabled = -not $IsBusy
    $btnDisconnect.Enabled = -not $IsBusy
    $btnRefresh.Enabled = -not $IsBusy
    if ($null -ne $btnSend) { $btnSend.Enabled = -not $IsBusy }
    if ($IsBusy) { $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor }
    else { $form.Cursor = [System.Windows.Forms.Cursors]::Default }
    [System.Windows.Forms.Application]::DoEvents()
}

function Send-CommandWithLog {
    param(
        [string]$Command,
        [scriptblock]$OnReply = $null
    )

    if ($script:Busy) {
        Add-Log "!! Busy, wait for current operation"
        return
    }

    Set-Busy $true
    try {
        if (-not $script:PipeConnected) {
            Add-Log "Connecting..."
            $ok = Connect-FlimagePipes -Log { param($line) Add-Log $line }
            Set-Status $ok
            if (-not $ok) {
                Add-Log "Connect failed"
                return
            }
            Add-Log "Connected"
        }

        Add-Log ">> $Command"
        $reply = Send-FlimagePipeCommand -Command $Command
        Add-Log "<< $reply"
        if ($null -ne $OnReply) { & $OnReply $reply }
    }
    catch {
        Set-Status $false $_.Exception.Message
        Add-Log "!! $($_.Exception.Message)"
    }
    finally {
        Set-Busy $false
    }
}

$filterGroup = New-Object System.Windows.Forms.GroupBox
$filterGroup.Text = "Filter cube turret (1MU)"
$filterGroup.Location = New-Object System.Drawing.Point 12, 48
$filterGroup.Size = New-Object System.Drawing.Size 740, 72
$form.Controls.Add($filterGroup)

$filterPosLabel = New-Object System.Windows.Forms.Label
$filterPosLabel.Text = "Current: --"
$filterPosLabel.Location = New-Object System.Drawing.Point 12, 30
$filterPosLabel.AutoSize = $true
$filterGroup.Controls.Add($filterPosLabel)

$filterNumeric = New-Object System.Windows.Forms.NumericUpDown
$filterNumeric.Minimum = $TurretMin
$filterNumeric.Maximum = $TurretMax
$filterNumeric.Value = 1
$filterNumeric.Location = New-Object System.Drawing.Point 120, 28
$filterNumeric.Width = 50
$filterGroup.Controls.Add($filterNumeric)

$btnFilterGet = New-Object System.Windows.Forms.Button
$btnFilterGet.Text = "Get"
$btnFilterGet.Location = New-Object System.Drawing.Point 180, 26
$btnFilterGet.Width = 50
$filterGroup.Controls.Add($btnFilterGet)

$btnFilterSet = New-Object System.Windows.Forms.Button
$btnFilterSet.Text = "Set"
$btnFilterSet.Location = New-Object System.Drawing.Point 236, 26
$btnFilterSet.Width = 50
$filterGroup.Controls.Add($btnFilterSet)

$filterButtons = @()
$x = 300
for ($pos = $TurretMin; $pos -le $TurretMax; $pos++) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = "$pos"
    $btn.Width = 32
    $btn.Height = 26
    $btn.Location = New-Object System.Drawing.Point $x, 26
    $filterGroup.Controls.Add($btn)
    $filterButtons += $btn
    $x += 36
}

$objGroup = New-Object System.Windows.Forms.GroupBox
$objGroup.Text = "Objective turret (1OB)"
$objGroup.Location = New-Object System.Drawing.Point 12, 128
$objGroup.Size = New-Object System.Drawing.Size 740, 72
$form.Controls.Add($objGroup)

$objPosLabel = New-Object System.Windows.Forms.Label
$objPosLabel.Text = "Current: --"
$objPosLabel.Location = New-Object System.Drawing.Point 12, 30
$objPosLabel.AutoSize = $true
$objGroup.Controls.Add($objPosLabel)

$objNumeric = New-Object System.Windows.Forms.NumericUpDown
$objNumeric.Minimum = $TurretMin
$objNumeric.Maximum = $TurretMax
$objNumeric.Value = 1
$objNumeric.Location = New-Object System.Drawing.Point 120, 28
$objNumeric.Width = 50
$objGroup.Controls.Add($objNumeric)

$btnObjGet = New-Object System.Windows.Forms.Button
$btnObjGet.Text = "Get"
$btnObjGet.Location = New-Object System.Drawing.Point 180, 26
$btnObjGet.Width = 50
$objGroup.Controls.Add($btnObjGet)

$btnObjSet = New-Object System.Windows.Forms.Button
$btnObjSet.Text = "Set"
$btnObjSet.Location = New-Object System.Drawing.Point 236, 26
$btnObjSet.Width = 50
$objGroup.Controls.Add($btnObjSet)

$objButtons = @()
$x = 300
for ($pos = $TurretMin; $pos -le $TurretMax; $pos++) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = "$pos"
    $btn.Width = 32
    $btn.Height = 26
    $btn.Location = New-Object System.Drawing.Point $x, 26
    $objGroup.Controls.Add($btn)
    $objButtons += $btn
    $x += 36
}

$cmdGroup = New-Object System.Windows.Forms.GroupBox
$cmdGroup.Text = "Custom pipe command"
$cmdGroup.Location = New-Object System.Drawing.Point 12, 208
$cmdGroup.Size = New-Object System.Drawing.Size 740, 88
$form.Controls.Add($cmdGroup)

$cmdBox = New-Object System.Windows.Forms.TextBox
$cmdBox.Location = New-Object System.Drawing.Point 12, 24
$cmdBox.Width = 560
$cmdGroup.Controls.Add($cmdBox)

$btnSend = New-Object System.Windows.Forms.Button
$btnSend.Text = "Send"
$btnSend.Location = New-Object System.Drawing.Point 580, 22
$btnSend.Width = 70
$cmdGroup.Controls.Add($btnSend)

$quickPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$quickPanel.Location = New-Object System.Drawing.Point 12, 52
$quickPanel.Size = New-Object System.Drawing.Size 710, 28
$quickPanel.WrapContents = $false
$cmdGroup.Controls.Add($quickPanel)

foreach ($quick in @(
        @{ Text = "GetFilterTurret"; Cmd = "GetFilterTurret" },
        @{ Text = "GetObjectiveTurret"; Cmd = "GetObjectiveTurret" },
        @{ Text = "GetRelativeXYZ"; Cmd = "GetRelativeXYZ" },
        @{ Text = "GetVersion"; Cmd = "GetVersion" }
    )) {
    $qb = New-Object System.Windows.Forms.Button
    $qb.Text = $quick.Text
    $qb.AutoSize = $true
    $qb.Tag = $quick.Cmd
    $quickPanel.Controls.Add($qb)
    $qb.Add_Click({
            $cmdBox.Text = $this.Tag
            Send-CommandWithLog -Command $this.Tag
        })
}

function Update-FilterLabel {
    param([string]$Reply)
    $value = Get-TurretValue -Reply $Reply -Token "FilterTurret"
    if ($null -ne $value) { $filterPosLabel.Text = "Current: $value" }
    elseif ($Reply -match '(?i)^Error') { $filterPosLabel.Text = "Current: ERR" }
}

function Update-ObjectiveLabel {
    param([string]$Reply)
    $value = Get-TurretValue -Reply $Reply -Token "ObjectiveTurret"
    if ($null -ne $value) { $objPosLabel.Text = "Current: $value" }
    elseif ($Reply -match '(?i)^Error') { $objPosLabel.Text = "Current: ERR" }
}

$btnConnect.Add_Click({
        if ($script:Busy) { return }
        Set-Busy $true
        try {
            Add-Log "Connecting..."
            $ok = Connect-FlimagePipes -Log { param($line) Add-Log $line }
            if ($ok) {
                Set-Status $true
                Add-Log "Connected"
                Add-Log ">> GetVersion"
                $reply = Send-FlimagePipeCommand -Command "GetVersion"
                Add-Log "<< $reply"
            }
            else {
                Set-Status $false "open FLIMage and retry"
                Add-Log "Connect failed"
            }
        }
        catch {
            Set-Status $false $_.Exception.Message
            Add-Log "!! $($_.Exception.Message)"
        }
        finally {
            Set-Busy $false
        }
    })

$btnDisconnect.Add_Click({
        Close-FlimagePipes
        Set-Status $false
        Add-Log "Disconnected"
    })

$btnRefresh.Add_Click({
        Send-CommandWithLog -Command "GetFilterTurret" -OnReply { param($r) Update-FilterLabel $r }
        Send-CommandWithLog -Command "GetObjectiveTurret" -OnReply { param($r) Update-ObjectiveLabel $r }
    })

$btnFilterGet.Add_Click({
        Send-CommandWithLog -Command "GetFilterTurret" -OnReply { param($r) Update-FilterLabel $r }
    })

$btnFilterSet.Add_Click({
        $value = [int]$filterNumeric.Value
        Send-CommandWithLog -Command "SetFilterTurret, $value" -OnReply {
            param($r)
            $done = Get-TurretValue -Reply $r -Token "FilterTurretDone"
            if ($null -eq $done) { $done = Get-TurretValue -Reply $r -Token "FilterTurret" }
            if ($null -ne $done) { $filterPosLabel.Text = "Current: $done" }
        }
    })

$btnObjGet.Add_Click({
        Send-CommandWithLog -Command "GetObjectiveTurret" -OnReply { param($r) Update-ObjectiveLabel $r }
    })

$btnObjSet.Add_Click({
        $value = [int]$objNumeric.Value
        Send-CommandWithLog -Command "SetObjectiveTurret, $value" -OnReply {
            param($r)
            $done = Get-TurretValue -Reply $r -Token "ObjectiveTurretDone"
            if ($null -eq $done) { $done = Get-TurretValue -Reply $r -Token "ObjectiveTurret" }
            if ($null -ne $done) { $objPosLabel.Text = "Current: $done" }
        }
    })

for ($i = 0; $i -lt $filterButtons.Count; $i++) {
    $capturePos = $TurretMin + $i
    $filterButtons[$i].Add_Click({
            $filterNumeric.Value = $capturePos
            Send-CommandWithLog -Command ("SetFilterTurret, {0}" -f [int]$filterNumeric.Value) -OnReply {
                param($r)
                $done = Get-TurretValue -Reply $r -Token "FilterTurretDone"
                if ($null -eq $done) { $done = Get-TurretValue -Reply $r -Token "FilterTurret" }
                if ($null -ne $done) { $filterPosLabel.Text = "Current: $done" }
            }
        }.GetNewClosure())
}

for ($i = 0; $i -lt $objButtons.Count; $i++) {
    $capturePos = $TurretMin + $i
    $objButtons[$i].Add_Click({
            $objNumeric.Value = $capturePos
            Send-CommandWithLog -Command ("SetObjectiveTurret, {0}" -f [int]$objNumeric.Value) -OnReply {
                param($r)
                $done = Get-TurretValue -Reply $r -Token "ObjectiveTurretDone"
                if ($null -eq $done) { $done = Get-TurretValue -Reply $r -Token "ObjectiveTurret" }
                if ($null -ne $done) { $objPosLabel.Text = "Current: $done" }
            }
        }.GetNewClosure())
}

$btnSend.Add_Click({
        $command = $cmdBox.Text.Trim()
        if ($command) { Send-CommandWithLog -Command $command }
    })

$cmdBox.Add_KeyDown({
        if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
            $command = $cmdBox.Text.Trim()
            if ($command) { Send-CommandWithLog -Command $command }
            $_.SuppressKeyPress = $true
        }
    })

$btnClearLog.Add_Click({ $logBox.Clear() })

$form.Add_FormClosed({ Close-FlimagePipes })

[void]$form.ShowDialog()
