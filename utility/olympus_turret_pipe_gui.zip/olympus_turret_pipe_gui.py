"""
Simple FLIMage named-pipe remote-control GUI for Olympus filter/objective turrets.

Uses the same pipe protocol as FLIM_pipeClient.py (FLIMageW / FLIMageR).
Run FLIMage with Remote Control enabled before connecting.
"""

from __future__ import annotations

import os
import re
import sys
import threading
import time
import tkinter as tk
from datetime import datetime
from tkinter import scrolledtext, ttk
from typing import Callable, Optional

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONTROLFLIMAGE_ROOT = os.path.dirname(SCRIPT_DIR)
if CONTROLFLIMAGE_ROOT not in sys.path:
    sys.path.insert(0, CONTROLFLIMAGE_ROOT)

from FLIM_pipeClient import FLIM_Com  # noqa: E402
from find_close_remotecontrol import close_remote_control  # noqa: E402


TURRET_MIN = 1
TURRET_MAX = 6


def _parse_turret_value(reply: str, token: str) -> Optional[int]:
    if not reply:
        return None
    match = re.search(rf"{token}\s*,\s*(-?\d+)", reply, flags=re.IGNORECASE)
    if not match:
        return None
    try:
        return int(match.group(1))
    except ValueError:
        return None


class FlimagePipeSession:
    """Thin wrapper around FLIM_Com with reconnect helpers."""

    def __init__(self, on_async_message: Callable[[str, str], None]):
        self._on_async_message = on_async_message
        self.flim = FLIM_Com()
        self.flim.print_responses = False
        self.flim.messageReceived += self._handle_async_message

    def _handle_async_message(self, data: str, source: str) -> None:
        self._on_async_message(source, data)

    def _connect_once(self) -> bool:
        self.flim.startServer()
        time.sleep(0.3)
        self.flim.startConnection()
        return bool(self.flim.Connected)

    def connect(self, retries: int = 3, retry_wait_sec: float = 1.0) -> bool:
        if self._connect_once():
            return True

        close_remote_control()
        time.sleep(0.5)
        self.flim = FLIM_Com()
        self.flim.print_responses = False
        self.flim.messageReceived += self._handle_async_message

        for attempt in range(2, retries + 1):
            if self._connect_once():
                return True
            if attempt < retries:
                time.sleep(retry_wait_sec)
        return False

    def disconnect(self) -> None:
        if self.flim.Connected:
            try:
                self.flim.disconnect()
            except Exception:
                pass
        try:
            self.flim.close()
        except Exception:
            pass

    @property
    def connected(self) -> bool:
        return bool(self.flim.Connected)

    def send_command(self, command: str) -> str:
        if not self.flim.Connected:
            raise RuntimeError("Not connected to FLIMage pipe")
        reply = self.flim.sendCommand(command)
        if reply is None:
            reply = getattr(self.flim, "Received", "") or "Connection problem"
        return reply


class OlympusTurretPipeGui(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("FLIMage Olympus Turret Pipe Tester")
        self.geometry("760x620")
        self.minsize(640, 520)

        self.session = FlimagePipeSession(self._log_async_message)
        self._busy = False

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self) -> None:
        conn_frame = ttk.LabelFrame(self, text="Connection")
        conn_frame.pack(fill="x", padx=10, pady=8)

        self.status_var = tk.StringVar(value="Disconnected")
        ttk.Label(conn_frame, textvariable=self.status_var).pack(side="left", padx=8, pady=6)

        ttk.Button(conn_frame, text="Connect", command=self._connect_clicked).pack(
            side="left", padx=4
        )
        ttk.Button(conn_frame, text="Disconnect", command=self._disconnect_clicked).pack(
            side="left", padx=4
        )
        ttk.Button(conn_frame, text="Refresh turrets", command=self._refresh_turrets).pack(
            side="left", padx=4
        )

        filter_frame = ttk.LabelFrame(self, text="Filter cube turret (1MU)")
        filter_frame.pack(fill="x", padx=10, pady=6)
        self._build_turret_row(
            filter_frame,
            position_var_name="filter_pos_var",
            spin_var_name="filter_spin_var",
            get_cmd="GetFilterTurret",
            set_cmd_prefix="SetFilterTurret",
            done_token="FilterTurret",
        )

        obj_frame = ttk.LabelFrame(self, text="Objective turret (1OB)")
        obj_frame.pack(fill="x", padx=10, pady=6)
        self._build_turret_row(
            obj_frame,
            position_var_name="objective_pos_var",
            spin_var_name="objective_spin_var",
            get_cmd="GetObjectiveTurret",
            set_cmd_prefix="SetObjectiveTurret",
            done_token="ObjectiveTurret",
        )

        cmd_frame = ttk.LabelFrame(self, text="Custom pipe command")
        cmd_frame.pack(fill="x", padx=10, pady=6)

        self.command_var = tk.StringVar()
        entry = ttk.Entry(cmd_frame, textvariable=self.command_var)
        entry.pack(side="left", fill="x", expand=True, padx=8, pady=6)
        entry.bind("<Return>", lambda _event: self._send_custom_command())

        ttk.Button(cmd_frame, text="Send", command=self._send_custom_command).pack(
            side="left", padx=4, pady=6
        )

        quick_frame = ttk.Frame(cmd_frame)
        quick_frame.pack(fill="x", padx=8, pady=(0, 6))
        for label, cmd in (
            ("GetFilterTurret", "GetFilterTurret"),
            ("GetObjectiveTurret", "GetObjectiveTurret"),
            ("GetRelativeXYZ", "GetRelativeXYZ"),
            ("PING", "GetVersion"),
        ):
            ttk.Button(
                quick_frame,
                text=label,
                command=lambda c=cmd: self._send_preset_command(c),
            ).pack(side="left", padx=2)

        log_frame = ttk.LabelFrame(self, text="Sent / received log")
        log_frame.pack(fill="both", expand=True, padx=10, pady=8)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=16, state="disabled")
        self.log_text.pack(fill="both", expand=True, padx=8, pady=6)

        ttk.Button(log_frame, text="Clear log", command=self._clear_log).pack(
            anchor="e", padx=8, pady=(0, 6)
        )

    def _build_turret_row(
        self,
        parent: ttk.LabelFrame,
        position_var_name: str,
        spin_var_name: str,
        get_cmd: str,
        set_cmd_prefix: str,
        done_token: str,
    ) -> None:
        row = ttk.Frame(parent)
        row.pack(fill="x", padx=8, pady=6)

        pos_var = tk.StringVar(value="--")
        setattr(self, position_var_name, pos_var)
        ttk.Label(row, text="Current:").pack(side="left")
        ttk.Label(row, textvariable=pos_var, width=4, font=("Segoe UI", 11, "bold")).pack(
            side="left", padx=(4, 12)
        )

        spin_var = tk.IntVar(value=1)
        setattr(self, spin_var_name, spin_var)
        spin = ttk.Spinbox(
            row,
            from_=TURRET_MIN,
            to=TURRET_MAX,
            textvariable=spin_var,
            width=5,
        )
        spin.pack(side="left", padx=4)

        ttk.Button(
            row,
            text="Get",
            command=lambda cmd=get_cmd, token=done_token, pv=pos_var: self._query_turret(
                cmd, token, pv
            ),
        ).pack(side="left", padx=4)

        ttk.Button(
            row,
            text="Set",
            command=lambda cmd=set_cmd_prefix, token=done_token, pv=pos_var, sv=spin_var: self._set_turret(
                cmd, token, pv, sv
            ),
        ).pack(side="left", padx=4)

        for pos in range(TURRET_MIN, TURRET_MAX + 1):
            ttk.Button(
                row,
                text=str(pos),
                width=3,
                command=lambda p=pos, sv=spin_var, cmd=set_cmd_prefix, token=done_token, pv=pos_var: self._set_turret_value(
                    cmd, token, pv, sv, p
                ),
            ).pack(side="left", padx=1)

    def _timestamp(self) -> str:
        return datetime.now().strftime("%H:%M:%S.%f")[:-3]

    def _append_log(self, line: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", line + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _log_async_message(self, source: str, data: str) -> None:
        self.after(0, lambda: self._append_log(f"[{self._timestamp()}] async/{source}: {data}"))

    def _log_sent(self, command: str) -> None:
        self._append_log(f"[{self._timestamp()}] >> {command}")

    def _log_reply(self, reply: str) -> None:
        self._append_log(f"[{self._timestamp()}] << {reply}")

    def _set_status(self, connected: bool, detail: str = "") -> None:
        if connected:
            text = "Connected"
        else:
            text = "Disconnected"
        if detail:
            text = f"{text} - {detail}"
        self.status_var.set(text)

    def _run_in_thread(self, task: Callable[[], None]) -> None:
        if self._busy:
            self._append_log(f"[{self._timestamp()}] !! Busy, wait for current operation")
            return

        def runner() -> None:
            self._busy = True
            try:
                task()
            finally:
                self._busy = False

        threading.Thread(target=runner, daemon=True).start()

    def _connect_clicked(self) -> None:
        def task() -> None:
            self.after(0, lambda: self._append_log(f"[{self._timestamp()}] Connecting..."))
            ok = self.session.connect()
            if ok:
                def on_connected() -> None:
                    self._set_status(True)
                    self._append_log(f"[{self._timestamp()}] Connected")
                    self._refresh_turrets()

                self.after(0, on_connected)
            else:
                self.after(
                    0,
                    lambda: self._set_status(
                        False, "open FLIMage Remote Control and retry"
                    ),
                )
                self.after(0, lambda: self._append_log(f"[{self._timestamp()}] Connect failed"))

        self._run_in_thread(task)

    def _disconnect_clicked(self) -> None:
        self.session.disconnect()
        self._set_status(False)
        self._append_log(f"[{self._timestamp()}] Disconnected")

    def _send_with_log(self, command: str, on_reply: Optional[Callable[[str], None]] = None) -> None:
        def task() -> None:
            if not self.session.connected:
                ok = self.session.connect()
                self.after(0, lambda: self._set_status(ok))
                if not ok:
                    self.after(
                        0,
                        lambda: self._append_log(
                            f"[{self._timestamp()}] !! Not connected; command skipped"
                        ),
                    )
                    return

            self.after(0, lambda: self._log_sent(command))
            try:
                reply = self.session.send_command(command)
            except Exception as exc:
                self.after(0, lambda: self._set_status(False, str(exc)))
                self.after(0, lambda: self._append_log(f"[{self._timestamp()}] !! {exc}"))
                return

            self.after(0, lambda: self._log_reply(reply))
            if on_reply is not None:
                self.after(0, lambda: on_reply(reply))

        self._run_in_thread(task)

    def _update_position_label(self, pos_var: tk.StringVar, token: str, reply: str) -> None:
        value = _parse_turret_value(reply, token)
        if value is not None:
            pos_var.set(str(value))
        elif reply.lower().startswith("error"):
            pos_var.set("ERR")

    def _query_turret(self, command: str, token: str, pos_var: tk.StringVar) -> None:
        self._send_with_log(
            command,
            on_reply=lambda reply: self._update_position_label(pos_var, token, reply),
        )

    def _set_turret_value(
        self,
        set_cmd_prefix: str,
        token: str,
        pos_var: tk.StringVar,
        spin_var: tk.IntVar,
        value: int,
    ) -> None:
        spin_var.set(value)
        self._set_turret(set_cmd_prefix, token, pos_var, spin_var)

    def _set_turret(
        self,
        set_cmd_prefix: str,
        token: str,
        pos_var: tk.StringVar,
        spin_var: tk.IntVar,
    ) -> None:
        try:
            value = int(spin_var.get())
        except (tk.TclError, ValueError):
            self._append_log(f"[{self._timestamp()}] !! Invalid turret value")
            return

        if value < TURRET_MIN or value > TURRET_MAX:
            self._append_log(
                f"[{self._timestamp()}] !! Turret position must be {TURRET_MIN}-{TURRET_MAX}"
            )
            return

        command = f"{set_cmd_prefix}, {value}"

        def on_reply(reply: str) -> None:
            done_value = _parse_turret_value(reply, f"{token}Done")
            if done_value is None:
                done_value = _parse_turret_value(reply, token)
            if done_value is not None:
                pos_var.set(str(done_value))
            elif reply.lower().startswith("error"):
                pos_var.set("ERR")

        self._send_with_log(command, on_reply=on_reply)

    def _refresh_turrets(self) -> None:
        self._query_turret("GetFilterTurret", "FilterTurret", self.filter_pos_var)
        self._query_turret("GetObjectiveTurret", "ObjectiveTurret", self.objective_pos_var)

    def _send_custom_command(self) -> None:
        command = self.command_var.get().strip()
        if not command:
            return
        self._send_with_log(command)

    def _send_preset_command(self, command: str) -> None:
        self.command_var.set(command)
        self._send_with_log(command)

    def _on_close(self) -> None:
        self.session.disconnect()
        self.destroy()


def main() -> None:
    app = OlympusTurretPipeGui()
    app.mainloop()


if __name__ == "__main__":
    main()
