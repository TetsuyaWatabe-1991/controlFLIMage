@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0olympus_turret_pipe_gui.ps1"
if errorlevel 1 pause
