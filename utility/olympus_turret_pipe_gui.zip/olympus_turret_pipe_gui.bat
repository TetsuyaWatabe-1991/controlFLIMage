@echo off
setlocal
cd /d "%~dp0\.."
python "%~dp0olympus_turret_pipe_gui.py"
if errorlevel 1 pause
